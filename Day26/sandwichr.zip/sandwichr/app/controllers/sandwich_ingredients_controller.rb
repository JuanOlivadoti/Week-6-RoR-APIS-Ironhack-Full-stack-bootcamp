class SandwichIngredientsController < ApplicationController
	
end
