class SandwichViewsController < ApplicationController

	def index
		@sandwiches = Sandwich.all
		# @sandwiches = @sandwiches.find(:id)
	end

	def show
		@sandwich = Sandwich.find(params[:id])
		@ingredients = @sandwich.ingredients
		@all_ingredients = Ingredient.all
	end

end
