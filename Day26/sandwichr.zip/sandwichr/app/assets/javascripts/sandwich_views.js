// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.

$(document).ready(function(){

	$('button').click(function(event){

	var sand_id = $('#1').prop('id');
	var ing_id = $(event.target).data('ing');
	console.log(ing_id);

		$.ajax ({
			type: "POST",
			url: "/api/sandwiches/" + sand_id + "/ingredients/add",
			data: {ingredient_id: ing_id},
			success: done,
			error: handleErrors
		});

	});
// ====== ERROR handler

function handleErrors(errors){
	console.log(errors);
}

function done(response){
	console.log("success!");
	location.reload(true);
}

});