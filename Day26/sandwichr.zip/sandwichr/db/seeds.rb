# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

sandwiches = Sandwich.create([
	{name: 'Italian', bread_type: 'White bread'},
	{name: 'Turkey', bread_type: 'Cereal bread'},
	{name: 'Salami', bread_type: 'Beer bread'},
	])

ingredients = Ingredient.create([
	{name: 'tomato', calories: '50'},
	{name: 'cheese', calories: '110'},
	{name: 'mustard', calories: '30'},
	{name: 'turkey', calories: '80'},
	{name: 'ham', calories: '100'},
	])

# sandwich_ingredients = Sandwich_ingredient.create([
# 	{sandwich_id: '1', ingredient_id: '2'},
# 	{sandwich_id: '2', ingredient_id: '1'},
# 	{sandwich_id: '2', ingredient_id: '3'},
# 	])
