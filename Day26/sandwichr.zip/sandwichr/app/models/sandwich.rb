class Sandwich < ActiveRecord::Base
	has_many :sandwich_ingredients
	has_many :ingredients, through: :sandwich_ingredients

	def add
		self.ingredients.push(ingredient)
		self.save
		self.total_calories += ingredients.calories
	end
end
